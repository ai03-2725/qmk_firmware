# The default keymap for AIC6L

Default keymap.
